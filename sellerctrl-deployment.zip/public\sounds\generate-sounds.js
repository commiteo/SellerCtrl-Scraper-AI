// Generate simple audio files using Web Audio API
// This script creates basic success and error sounds

const fs = require('fs');
const { execSync } = require('child_process');

console.log('🎵 Generating sound files...');

// Create a simple HTML file to generate sounds
const htmlContent = `
<!DOCTYPE html>
<html>
<head>
    <title>Sound Generator</title>
</head>
<body>
    <h1>Sound Generator</h1>
    <button onclick="generateSuccessSound()">Generate Success Sound</button>
    <button onclick="generateErrorSound()">Generate Error Sound</button>
    <button onclick="downloadAll()">Download All Sounds</button>
    
    <script>
        function generateTone(frequency, duration, type = 'sine') {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
            oscillator.type = type;
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + duration);
            
            return { audioContext, oscillator, gainNode };
        }
        
        function generateSuccessSound() {
            // Success sound: ascending tones
            generateTone(523.25, 0.2); // C5
            setTimeout(() => generateTone(659.25, 0.2), 200); // E5
            setTimeout(() => generateTone(783.99, 0.3), 400); // G5
        }
        
        function generateErrorSound() {
            // Error sound: descending tones
            generateTone(783.99, 0.2); // G5
            setTimeout(() => generateTone(659.25, 0.2), 200); // E5
            setTimeout(() => generateTone(523.25, 0.3), 400); // C5
        }
        
        function downloadAll() {
            alert('Please record the sounds manually or use the browser console to generate them.');
        }
    </script>
</body>
</html>
`;

fs.writeFileSync('sound-generator.html', htmlContent);
console.log('✅ Created sound-generator.html');
console.log('📝 Instructions:');
console.log('1. Open sound-generator.html in your browser');
console.log('2. Click the buttons to hear the sounds');
console.log('3. Use browser dev tools to record the audio');
console.log('4. Save as MP3 files in public/sounds/'); 